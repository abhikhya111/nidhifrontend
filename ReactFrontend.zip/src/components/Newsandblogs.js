import React from 'react';
import Header from '../Header';
import Footer from '../Footer';
const Newsandblogs = () => {
    return (
        <>
            <Header />
            <Footer />
        </>
    )
}
export default Newsandblogs;