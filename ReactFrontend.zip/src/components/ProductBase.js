import React from 'react';
import './ProductBase.css';
import Header from '../Header';
import Footer from '../Footer';
import Banner from './ProductBanner.png';
import RectangleProduct1 from './RectangleProduct1.png';
import RectangleProduct2 from './RectangleProduct2.png';
import RectangleProduct3 from './RectangleProduct3.png';
import RectangleProduct4 from './RectangleProduct4.png';
import Product1 from './Product1.png'
import { Row, Col, Navbar, Nav } from 'react-bootstrap'
export default function ProductBase() {
    return (
        <div className='container-fluid '>
            <Header />
            <Row className='m-4 p-2'>
                <Col md={4} className='colNo  colWidth'>
                    <div className='p-2'>
                        <Row className=''><h4>XPT 400 ANGLE GRINDER</h4></Row>
                        <Row className='p-4'><img src={Product1} className='BannerImg border border-danger colImg' /></Row>
                        {/* <Row className='p-3'><img src={RectangleProduct3} className='border border-danger'/></Row>
                        <Row className='p-3'><img src={RectangleProduct4} className='border border-danger'/></Row> */}
                    </div>
                </Col>
                <Col md={2} className='colNo colWidth'>
                    <div className='p-4'>
                        <Row className='p-3'><img src={RectangleProduct1} className='border border-danger imgWidth' /></Row>
                        <Row className='p-3'><img src={RectangleProduct2} className='border border-danger imgWidth' /></Row>
                        <Row className='p-3'><img src={RectangleProduct3} className='border border-danger imgWidth' /></Row>
                        <Row className='p-3'><img src={RectangleProduct4} className='border border-danger imgWidth' /></Row>
                    </div>
                </Col>
                <Col md={6} className='colNo colWidthc '>
                    <div className='p-4'>
                        <Row className=''>
                            <Col><h5 className=''>Specification</h5></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Power Source Type</p></Col>
                            <Col><p>Double Insulation Electric Corded</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Brand</p></Col>
                            <Col><p>XTRA-POWER</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Colour</p></Col>
                            <Col><p>Red & Black</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>No Load Speed</p></Col>
                            <Col><p>8300 RPM</p></Col>
                        </Row><Row className=''>
                            <Col><p>Voltage</p></Col>
                            <Col><p>220/240 V</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Frequency</p></Col>
                            <Col><p>50/60 Hz</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Spindle Thread</p></Col>
                            <Col><p>M14</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Disc Diameter</p></Col>
                            <Col><p>180MM</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Input Power	</p></Col>
                            <Col><p>2050 Watts</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Spindle Lock</p></Col>
                            <Col><p>Yes</p></Col>
                        </Row>
                        <Row className=''>
                            <Col><p>Spindle Thread</p></Col>
                            <Col><p>M14</p></Col>
                        </Row>
                    </div>
                </Col>
            </Row>
            <Row className='rowSec p-5 divJust'>
                <Col md={5} className='mt-4'>
                    <div className='divNum'></div>
                </Col>
                <Col md={4}>
                    <h4>About this item</h4>
                    <ul className='p-2'>
                        <li>Embraces 180mm disc</li>
                        <li>Solid 2050 watts motor</li>
                        <li>Adjustable lightweight build</li>
                        <li>Backside switch with lock lever</li>
                        <li>Side handle with three positions</li>
                        <li>An efficient slim body enables consistent use</li>
                        <li>Sturdy metal gears for higher tool reliability and enhanced tool life</li>
                    </ul>
                </Col>
                <Col md={3}>
                    <h4>Package Contents</h4>
                    <ul className='mt-2'>
                        <li>1 unit Angle Grinder</li>
                        <li>1 unit Wheel Guard</li>
                        <li>1 unit Side Handle</li>
                        <li>1 Pair Carbon Brush</li>
                        <li>1 unit Spanner</li>
                        <li>1 unit User Manual</li>
                    </ul>
                </Col>
            </Row>
            <Row className=''>
                <div>
                    {/* <Navbar className="text-dark bg-light">
                        <Nav>
                            <Nav.Link href="#" className=''>Home</Nav.Link>
                            <Nav.Link href="#" className=''>Products</Nav.Link>
                            <Nav.Link href="#" className=''>News and Blogs</Nav.Link>
                        </Nav>
                    </Navbar> */}
                </div>
            </Row>
            <Footer />
        </div>
    )
}