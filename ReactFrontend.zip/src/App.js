import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import ProductDetails from './components/ProductDetails';
import ProductBase from './components/ProductBase';
import Career from './components/Career';
import AboutUs from './components/AboutUs';
import Newsandblogs from './components/Newsandblogs';
import Csr from './components/Csr';
import Geographical from './components/Geographical';
import Gallery from './components/Gallery';
import ContactUs from './components/ContactUs';
export default function App() {
  // const [data, setData] = useState([]);
  // const getData = async () => {
  //   const { data } = await axios.get(`http://localhost:8000/api/getCategories`);
  //   setData(data);
  // };
  // useEffect(() => {
  //   getData();
  // }, []);
  return (<>
    <div className='app'>
      <Router>
        <Routes>
          <Route path="/homepage" element={<ProductDetails />} />
          <Route path='/productBase' element={<ProductBase />} />
          <Route path='/career' element={<Career />} />
          <Route path='/about-us' element={<AboutUs />} />
          <Route path="/news-and-blogs" element={<Newsandblogs />} />
          <Route path='/csr' element={<Csr />} />
          <Route path='/geographical-presence' element={<Geographical />} />
          <Route path='/gallery' element={<Gallery />} />
          <Route path="/contact-us" element={<ContactUs />} />
        </Routes>
      </Router>
    </div>
  </>
  );
}



